function playVideo(videoSrc) {
  const videoPlayer = document.getElementById("main-video");
  videoPlayer.src = videoSrc;
  videoPlayer.play();
}

function searchVideo() {
  const searchValue = document.getElementById("search").value.toLowerCase();
  alert("You searched for: " + searchValue);
}let likeCount = 0;
let dislikeCount = 0;

function likeVideo() {
  likeCount++;
  document.getElementById("like-count").innerText = likeCount;
}

function dislikeVideo() {
  dislikeCount++;
  document.getElementById("dislike-count").innerText = dislikeCount;
}const videoPlayer = document.getElementById("main-video");
const progress = document.getElementById("progress");

videoPlayer.addEventListener("timeupdate", () => {
  const percentage = (videoPlayer.currentTime / videoPlayer.duration) * 100;
  progress.style.width = percentage + "%";
});
function uploadVideo() {
  const videoFile = document.getElementById("video-upload").files[0];
  if (videoFile) {
    alert(`Video "${videoFile.name}" uploaded successfully! (Demo only)`);
  } else {
    alert("Please select a video to upload.");
  }
}